.. _nblib:

=========
NBLIB API
=========

This documentation is part of the `GROMACS manual <http://manual.gromacs.org/current/>`_
and describes the *nblib* API.


..  toctree::
    :maxdepth: 1
    :caption: Documentation sections

    guide-to-writing-MD-programs.rst
