*******************
Short How-To guides
*******************

.. highlight:: bash

A number of short guides are presented here to help users getting started with simulations.
Useful third-party tutorials provided by Justin Lemkul are found here http://www.mdtutorials.com/.

.. toctree::
   :maxdepth: 2

   beginners
   topology
   special
   visualize
